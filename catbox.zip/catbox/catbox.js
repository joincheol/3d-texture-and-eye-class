let img;
function setup() {
  createCanvas(400, 400,WEBGL);
  img = loadImage("cat.jpg");
}

function draw() {
  background(220);
  texture(img);
  rotateX(frameCount*0.01);
  rotateY(frameCount*0.01);
  box(200);
}
